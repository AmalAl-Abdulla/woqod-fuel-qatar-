package cmps312.qu.edu.qa.woqodfuelqatar;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.UnicodeSetSpanner;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class CalculateCost extends AppCompatActivity {
    EditText liters,price;
    DateFormat dateFormat = DateFormat.getDateInstance();
    TextView totalcost;
    static boolean isAdded;
    Button button,button2,buttonClear;
    static final String DATE = "date";
    static final String AMOUNT = "amount";
    static final String COST ="cost";
    static final String TYPE = "type";
    static final String PRICE = "price";
    static final String ADDED = "added";
    String[] types={"DIESEL","GASOLINE PREMIUM (91)","GASOLINE SUPER (95)"};
    Spinner spinner;
    String fuelType;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_cost);
        liters = (EditText) findViewById(R.id.enteredLiters);
        price = (EditText) findViewById(R.id.enterdprice);
        spinner = (Spinner) findViewById(R.id.spinner_type);
        buttonClear = (Button) findViewById(R.id.clear_contents);
        isAdded = false;
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, types);
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                switch (position){
                    case 0 : fuelType = types[0];
                        break;
                    case 1 : fuelType = types[1];
                        break;
                    case 2 : fuelType = types[2];

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        totalcost = (TextView) findViewById(R.id.totalcost);

        button = (Button) findViewById(R.id.button1);

        button2 = (Button) findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.woqod.com/EN/Gas/Pages/Fuel-Price.aspx"));
                startActivity(i);
            }
        });

        button2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Double cost = Double.valueOf(price.getText().toString())* Double.valueOf(liters.getText().toString());

                String result = String.format("%.2f", cost);

                totalcost.setText(result + "QR");

                /**
                fuelDate = dateFormat.format(Calendar.getInstance().getTime());
                fuelPrice = price.getText().toString();
                fuelAmount = liters.getText().toString();
                fuelCost = totalcost.getText().toString();
*/

                /**
                Intent intent = new Intent();
                Toast.makeText(CalculateCost.this,"setting intent values!", Toast.LENGTH_SHORT).show();
                intent.putExtra(TYPE,fuelType);
                intent.putExtra(PRICE,price.getText().toString());
                intent.putExtra(AMOUNT, liters.getText().toString());
                intent.putExtra(DATE,dateFormat.format(Calendar.getInstance().getTime()));
                intent.putExtra(COST,totalcost.getText().toString());
                intent.putExtra(ADDED,isAdded);
                setResult(Activity.RESULT_OK,intent);
                 */
                SharedPreferences preferences = getSharedPreferences("MyData",MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("date",dateFormat.format(Calendar.getInstance().getTime()));
                editor.putString("type",fuelType);
                editor.putString("price",price.getText().toString());
                editor.putString("amount",liters.getText().toString());
                editor.putString("cost",totalcost.getText().toString());
                editor.commit();
                isAdded = true;

            }
        });


        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                price.setText(" ");
                liters.setText(" ");
                totalcost.setText(" ");
            }
        });
    }
}


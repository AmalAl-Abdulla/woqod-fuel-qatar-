package cmps312.qu.edu.qa.woqodfuelqatar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private Button calculateCost, summaries,maps;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculateCost = (Button) findViewById(R.id.calculate_cost);
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        imageView = (ImageView) findViewById(R.id.image);
        setSupportActionBar(toolbar);

        maps = (Button) findViewById(R.id.button3);

        summaries = (Button) findViewById(R.id.summaries);

        summaries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToSummaries = new Intent(MainActivity.this, SummariesActivity.class);
                startActivity(goToSummaries);
            }
        });

        maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToSummaries = new Intent(MainActivity.this, Map.class);
                startActivity(goToSummaries);
            }
        });
        calculateCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent i = new Intent(MainActivity.this, CalculateCost.class);

                startActivity(i);


            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.our_menue,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch(item.getItemId()){


            case R.id.item1:
                Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.woqod.com/EN/Gas/Pages/FAQs.aspx"));
                startActivity(intent1);
                break;
            case R.id.item2:
                Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.woqod.com/EN/Gas/Pages/Services.aspx"));
                startActivity(intent2);
                break;
            case R.id.item3:
                Intent intent3 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.woqod.com/EN/Feedback/Pages/Contact_Us.aspx"));
                startActivity(intent3);
                break;


        }
        return super.onOptionsItemSelected(item);
    }


}

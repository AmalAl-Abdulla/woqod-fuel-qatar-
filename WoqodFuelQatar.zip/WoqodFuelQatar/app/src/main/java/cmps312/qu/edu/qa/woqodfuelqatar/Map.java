package cmps312.qu.edu.qa.woqodfuelqatar;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class Map extends FragmentActivity implements OnMapReadyCallback {
    EditText lat,lon;
    private GoogleMap mMap;
    double dLat=25.375;
    double dLon=51.489;
    SupportMapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    public void update(View v)
    {
        dLat= Double.parseDouble(lat.getText().toString());
        dLon=Double.parseDouble(lon.getText().toString());
        mapFragment.getMapAsync(this);
    }
    public void zoomIn(View v)
    {
        mMap.animateCamera(CameraUpdateFactory.zoomIn());


    }
    public void zoomOut(View v)
    {
        mMap.animateCamera(CameraUpdateFactory.zoomOut());

    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng loc = new LatLng(25.153455, 51.517467);
        LatLng loc2 = new LatLng(25.321208, 51.530164);
        LatLng loc3 = new LatLng(25.258713, 51.536520);
        LatLng loc4 = new LatLng(25.280135, 51.530147);
        LatLng loc5 = new LatLng(25.334458, 51.492830);
        LatLng loc6 = new LatLng(25.357443, 51.510502);
        LatLng loc7 = new LatLng(25.272602, 51.553591);
        LatLng loc8 = new LatLng(25.230183, 51.515758);
        LatLng loc9 = new LatLng(25.284105, 51.546610);
        LatLng loc10 = new LatLng(25.383284, 51.470707);
        LatLng loc11 = new LatLng(25.215258, 51.598969);
        LatLng loc12 = new LatLng(25.234382, 51.438293);
        LatLng loc13 = new LatLng(25.275551, 51.408780);
        LatLng loc14 = new LatLng(25.346902, 51.434872);
        LatLng loc15 = new LatLng(25.371034, 51.374103);
        LatLng loc16 = new LatLng(25.147934, 51.598013);
        LatLng loc17 = new LatLng(25.441548, 51.414821);
        LatLng loc18 = new LatLng(25.330412, 51.415315);
        LatLng loc19 = new LatLng(25.223717, 51.358115);
        LatLng loc20 = new LatLng(25.262527, 51.428836);
        LatLng loc21 = new LatLng(25.301648, 51.445486);
        LatLng loc22 = new LatLng(25.433271, 51.410958);
        LatLng loc23 = new LatLng(25.304110, 51.473668);
        LatLng loc24 = new LatLng(25.361483, 51.510060);
        LatLng loc25 = new LatLng(25.403635, 51.506970);
        LatLng loc26 = new LatLng(25.183529, 51.543060);
        LatLng loc27 = new LatLng(25.379443, 51.556065);




















        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(loc).title("Woqod Petrol station (Al Wukair)"));
        mMap.addMarker(new MarkerOptions().position(loc2).title("Woqod Tower"));
        mMap.addMarker(new MarkerOptions().position(loc3).title("Woqod Petrol Station Hilal"));
        mMap.addMarker(new MarkerOptions().position(loc4).title("Woqod Petrol Station"));
        mMap.addMarker(new MarkerOptions().position(loc5).title("Woqod Petrol Station Al Markhiya"));
        mMap.addMarker(new MarkerOptions().position(loc6).title("Woqod Petrol Station Laktifya"));
        mMap.addMarker(new MarkerOptions().position(loc7).title("Woqod Petrol Station Umm Ghuwailina"));
        mMap.addMarker(new MarkerOptions().position(loc8).title("Woqod Petrol Station Al Muntazah"));
        mMap.addMarker(new MarkerOptions().position(loc9).title("Woqod Petrol Station Old Al Ghanim"));
        mMap.addMarker(new MarkerOptions().position(loc10).title("Woqod Petrol Station (Wadi Al Banaat)"));
        mMap.addMarker(new MarkerOptions().position(loc11).title("WWoqod Petrol Station (Wakrah Road)"));
        mMap.addMarker(new MarkerOptions().position(loc12).title("Woqod Petrol Station Industrial"));
        mMap.addMarker(new MarkerOptions().position(loc13).title("Woqod Petrol Station Al Wajba"));
        mMap.addMarker(new MarkerOptions().position(loc14).title("Petrol Station - Al Gharrafa"));
        mMap.addMarker(new MarkerOptions().position(loc15).title("Woqod Al Themaid Petrol Station"));
        mMap.addMarker(new MarkerOptions().position(loc16).title("Woqod Petrol Station (Mesaieed Road)"));
        mMap.addMarker(new MarkerOptions().position(loc17).title("Woqod Petrol Station Rawdat Hamama"));
        mMap.addMarker(new MarkerOptions().position(loc18).title("Woqod Al Rayyan Fuel Station"));
        mMap.addMarker(new MarkerOptions().position(loc19).title("Woqod Petrol Station "));
        mMap.addMarker(new MarkerOptions().position(loc20).title("Woqod Petrol Station "));
        mMap.addMarker(new MarkerOptions().position(loc21).title("Woqod Petrol Station "));
        mMap.addMarker(new MarkerOptions().position(loc22).title("Woqod Petrol Station "));
        mMap.addMarker(new MarkerOptions().position(loc23).title("Woqod Petrol Station "));
        mMap.addMarker(new MarkerOptions().position(loc24).title("Woqod Petrol & Service Station, Onaiza "));
        mMap.addMarker(new MarkerOptions().position(loc25).title("Woqod Petrol Station Lusail"));
        mMap.addMarker(new MarkerOptions().position(loc26).title("Woqod Petrol Station (Al Mashaf)"));
        mMap.addMarker(new MarkerOptions().position(loc27).title("Woqod Petrol Station "));









        mMap.moveCamera(CameraUpdateFactory.newLatLng(loc));

    }}

package cmps312.qu.edu.qa.woqodfuelqatar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SummariesActivity extends AppCompatActivity {

    private ListView summariesList;
    private ArrayList<UserSummary> userSummariesList;
    private String fuelType, fuelPrice, fuelAmount, date, cost;
    private TextView textViewDate,textViewFuelAmount,textViewPrice,textViewCost,textViewFuelType, textViewId;
    private SummaryDataBase dataBase;
    private SummaryAdapter adapter;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summaries);


        summariesList = (ListView) findViewById(R.id.list_summaries);
        userSummariesList = new ArrayList<>();
        dataBase = new SummaryDataBase(this);


        //added = getIntent().getBooleanExtra(CalculateCost.ADDED,false);

        if(CalculateCost.isAdded==true) {
            SharedPreferences preferences = getSharedPreferences("MyData", MODE_PRIVATE);
            date = preferences.getString("date", "");
            fuelPrice = preferences.getString("price", "");
            fuelType = preferences.getString("type", "");
            fuelAmount = preferences.getString("amount", "");
            cost = preferences.getString("cost", "");
            dataBase.addItem(date, fuelType, fuelPrice, fuelAmount, cost);
            Toast.makeText(SummariesActivity.this, "summary added", Toast.LENGTH_SHORT).show();
        }else
            Toast.makeText(SummariesActivity.this,"view your sammaries",Toast.LENGTH_SHORT).show();

        cursor = dataBase.getAllItems();

        while(cursor.moveToNext()) {

            userSummariesList.add(new UserSummary(cursor.getString(0),cursor.getString(1),cursor.getString(2),
                    cursor.getString(3),cursor.getString(4)
                    ,cursor.getString(5)));
        }
        Log.e(SummariesActivity.class.getSimpleName(),"Error intializing adapter");
        adapter = new SummaryAdapter(SummariesActivity.this,userSummariesList);
        summariesList.setAdapter(adapter);

    }


    private class SummaryAdapter extends ArrayAdapter<UserSummary>{

        public SummaryAdapter(Context c, ArrayList<UserSummary> summariesList){
            super(c,0,summariesList);
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull final ViewGroup parent) {
            Log.e(SummariesActivity.class.getSimpleName(),"Error reaching adapter");

            UserSummary userSummary = getItem(position);

            if(convertView==null){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.summaties_list_row,null);
            }


            textViewDate = (TextView) convertView.findViewById(R.id.date);
            textViewFuelAmount = (TextView) convertView.findViewById(R.id.fuel_amount);
            textViewPrice = (TextView) convertView.findViewById(R.id.fuel_price);
            textViewFuelType = (TextView) convertView.findViewById(R.id.fuel_type);
            textViewCost = (TextView) convertView.findViewById(R.id.cost);
            textViewId = (TextView) convertView.findViewById(R.id.summary_id);

            Log.e(SummariesActivity.class.getSimpleName(),"Error intializing text views");
            textViewDate.setText(userSummary.getDate());
            textViewFuelType.setText(userSummary.getType());
            textViewPrice.setText(userSummary.getPrice());
            textViewFuelAmount.setText(userSummary.getFuelAmount());
            textViewCost.setText(userSummary.getCost());
            textViewId.setText(userSummary.getId());
            Log.e(SummariesActivity.class.getSimpleName(),"Error setting text views");


            convertView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(SummariesActivity.this)
                            .setTitle("Are you sure you want to delete?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    userSummariesList.remove(position);
                                    dataBase.deleteItems(textViewId.getText().toString());
                                    Toast.makeText(SummariesActivity.this,"summary deleted",Toast.LENGTH_SHORT).show();
                                    adapter.notifyDataSetChanged();
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            }).setIcon(R.drawable.delete_image);

                    dialog.show();
                    return true;
                }
            });


            return convertView;
        }
    }


/**
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { //request code is for activities
        super.onActivityResult(requestCode, resultCode, data);

      if(requestCode==101) {
          if (resultCode == Activity.RESULT_OK) {
              date = data.getStringExtra(CalculateCost.DATE);
              fuelType = data.getStringExtra(CalculateCost.TYPE);
              fuelPrice = data.getStringExtra(CalculateCost.PRICE);
              fuelAmount = data.getStringExtra(CalculateCost.AMOUNT);
              cost = data.getStringExtra(CalculateCost.COST);
              Toast.makeText(SummariesActivity.this, "onActivityResult reached!!", Toast.LENGTH_SHORT).show();
              dataBase.addItem(date, fuelType, fuelPrice, fuelAmount, cost);
          }
      }
    }*/

}
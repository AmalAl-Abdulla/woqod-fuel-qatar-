package cmps312.qu.edu.qa.woqodfuelqatar;

/**
 * Created by mooli_000 on 12/15/2017.
 */

public class UserSummary {

    private String id;
    private String date;
    private String type;
    private String price;
    private String fuelAmount;
    private String cost;


    public UserSummary() {
    }

    public UserSummary(String id,String date, String type, String price, String fuelAmount, String cost) {
        this.id = id;
        this.date = date;
        this.type = type;
        this.price = price;
        this.fuelAmount = fuelAmount;
        this.cost = cost;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFuelAmount() {
        return fuelAmount;
    }

    public void setFuelAmount(String fuelAmount) {
        this.fuelAmount = fuelAmount;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
